# Relatório de Estrutura do Projeto: Fidelidade

Este documento descreve a arquitetura e os componentes principais do projeto Django **Fidelidade**, analisado a partir do repositório fornecido.

## 1. Visão Geral da Arquitetura
O projeto segue o padrão **MVT (Model-View-Template)** do Django, organizado em dois aplicativos principais que separam as responsabilidades de autenticação e lógica de negócios.

| Componente | Descrição |
| :--- | :--- |
| **fidelidade/** | Diretório raiz de configuração do projeto (settings, urls, wsgi). |
| **accounts/** | Gerenciamento de usuários, perfis e autenticação. |
| **core/** | Lógica principal do sistema de fidelidade (comércios, promoções, pontos). |

---

## 2. Modelagem de Dados (Models)

### App: `accounts`
O projeto utiliza um modelo de usuário personalizado para diferenciar os tipos de participantes.
*   **CustomUser**: Estende `AbstractUser`. Possui campos para `tipo_usuario` (Cliente ou Comerciante), `cpf`, `cnpj` e `telefone`.

### App: `core`
Contém a inteligência do sistema de pontos e recompensas.
*   **Cidade**: Armazena cidades e estados para filtragem de comércios.
*   **Comercio**: Vinculado a um `CustomUser` (Comerciante). Contém dados empresariais e localização.
*   **Cliente**: Vinculado a um `CustomUser` (Cliente).
*   **Promocao**: Criada por um `Comercio`. Define os pontos necessários e o prêmio.
*   **Pontuacao**: Registra o progresso de um `Cliente` em uma `Promocao`. Gerencia o resgate de prêmios via código único.

---

## 3. Fluxo de Navegação e URLs
As rotas principais estão divididas entre autenticação e operações de fidelidade:

### Autenticação (`accounts`)
*   `/accounts/login/`: Acesso ao sistema.
*   `/registrar/cliente/` e `/registrar/comerciante/`: Fluxos de cadastro distintos.
*   `/confirmar-email/`: Validação de conta.

### Operações (`core`)
*   `/`: Dashboard principal (varia conforme o tipo de usuário).
*   `/criar-promocao/`: Interface para comerciantes criarem novas ofertas.
*   `/ler-qr-code/`: Funcionalidade para atribuição de pontos.
*   `/painel-resgate/`: Gestão de prêmios a serem entregues.

---

## 4. Estrutura de Arquivos
```text
fidelidade/
├── accounts/             # Gestão de Usuários
│   ├── models.py         # CustomUser
│   └── views.py          # Lógica de Registro/Login
├── core/                 # Lógica de Negócio
│   ├── models.py         # Comercio, Promocao, Pontuacao
│   └── views.py          # Dashboards e Regras de Pontos
├── fidelidade/           # Configurações Globais
│   ├── settings.py
│   └── urls.py
├── templates/            # Interface (HTML)
└── static/               # Ativos (CSS/JS)
```
